package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabFareMicroServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabFareMicroServiceAppApplication.class, args);
	}

}
